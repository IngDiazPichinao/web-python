For assistance see:
http://www.picnet.com.au/picnet_table_filter.html

To get demosrc.htm to run:
Download the closure library to lib/closure-library


How to compile picnet.table.filter.min.js
Download the closure library to lib/closure-library
Dowload and install Python 2.7
Modify the compile.bat file to match your installation folder of Python and the closure library
Run the compile.bat file