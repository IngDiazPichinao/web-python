
goog.require('goog.events.Event');

goog.require('picnet.ui.filter.TableFilter');
goog.require('picnet.ui.filter.jQueryPlugin');