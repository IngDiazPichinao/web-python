goog.require('goog.dom');
goog.require('goog.events');
goog.require('goog.style');

goog.require('picnet.cdm.CDM');
goog.require('picnet.cdm.data.DataManager');
goog.require('picnet.ui.EntityGrid');
goog.require('picnet.ui.EntityEdit');
goog.require('picnet.ui.GridRowCommand');